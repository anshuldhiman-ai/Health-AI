# Offline Vision Mobile Engineer

A reusable AI-agent skill for engineering offline-first Flutter/Android applications with on-device ML.

## Package contents

- `SKILL.md` — entry point and mandatory workflow
- `references/` — architecture, ML, privacy, numerical, safety, and project-baseline guidance
- `workflows/` — repeatable procedures for feature work, model integration, privacy audits, and release debugging
- `EVALUATION.md` — scenarios for checking whether an agent follows the skill

## How to use

1. Place this skill folder in the skills directory supported by your coding agent.
2. Make the skill available to the agent.
3. Ask the agent to inspect the repository before changing code.
4. For each task, ask it to cite exact file paths and report only checks it actually ran.

The skill is designed to adapt to a repository. Health-AI-specific observations are isolated in `references/health-ai-project-baseline.md`; they are not universal rules.

## Scope and exclusions

This package contains original guidance and summarized engineering observations. It intentionally does not contain Health-AI application source, model weights, datasets, nutrition catalogs, private credentials, or user data.

## Version

0.2.0 — repository-informed draft. Review the limitations in `references/health-ai-project-baseline.md` before treating the project snapshot as current.
